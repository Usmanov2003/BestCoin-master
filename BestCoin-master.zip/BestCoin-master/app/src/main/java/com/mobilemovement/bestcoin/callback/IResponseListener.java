package com.mobilemovement.bestcoin.callback;

public interface IResponseListener {
    void onFailure();
    void onSuccess();
}
